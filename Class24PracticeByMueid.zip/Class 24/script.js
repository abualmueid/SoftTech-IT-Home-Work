alert("Hello World !");

alert("1");

alert(2+3);

alert("1"+2+3+4);

alert(2.5+1.5);

alert(2.5+1);